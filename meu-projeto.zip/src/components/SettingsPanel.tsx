import type { ReaderSettings } from '../types';

interface SettingsPanelProps {
  settings: ReaderSettings;
  onSettingsChange: (settings: ReaderSettings) => void;
  onClose: () => void;
}

export default function SettingsPanel({ settings, onSettingsChange, onClose }: SettingsPanelProps) {
  const themes = [
    { value: 'light' as const, label: 'Claro', icon: '☀️', desc: 'Leitura diurna' },
    { value: 'sepia' as const, label: 'Sepia', icon: '📜', desc: 'Clássico' },
    { value: 'dark' as const, label: 'Noturno', icon: '🌙', desc: 'Confortável' },
  ];

  return (
    <div className="fixed inset-0 bg-charcoal-900/70 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-gradient-to-br from-ivory-50 to-ivory-100 rounded-3xl shadow-elegant w-full max-w-lg overflow-hidden animate-fade-in">
        {/* Header */}
        <div className="p-8 bg-gradient-to-r from-burgundy-600 to-burgundy-700">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-display font-semibold text-ivory-50 tracking-wide">
                Configurações
              </h2>
              <p className="text-ivory-200 text-sm mt-1 font-sans font-light">
                Personalize sua experiência de leitura
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-3 rounded-xl hover:bg-burgundy-500 text-ivory-50 transition-all duration-300 hover:rotate-90"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
        
        {/* Content */}
        <div className="p-8 space-y-8">
          {/* Theme Selection */}
          <div>
            <label className="block text-sm font-semibold text-charcoal-700 mb-4 tracking-wide uppercase">
              Tema de Leitura
            </label>
            <div className="grid grid-cols-3 gap-4">
              {themes.map((theme) => (
                <button
                  key={theme.value}
                  onClick={() => onSettingsChange({ ...settings, theme: theme.value })}
                  className={`
                    p-5 rounded-2xl border-2 transition-all duration-300 group
                    ${settings.theme === theme.value
                      ? 'border-burgundy-600 bg-gradient-to-br from-burgundy-50 to-burgundy-100 shadow-lg shadow-burgundy-600/20 scale-105'
                      : 'border-ivory-300 hover:border-burgundy-400 hover:shadow-soft'
                    }
                  `}
                >
                  <div className="text-4xl mb-2 transition-transform group-hover:scale-110">{theme.icon}</div>
                  <div className="text-base font-medium text-charcoal-800">{theme.label}</div>
                  <div className="text-xs text-charcoal-500 mt-1">{theme.desc}</div>
                </button>
              ))}
            </div>
          </div>
          
          {/* Font Size */}
          <div>
            <label className="block text-sm font-semibold text-charcoal-700 mb-4 tracking-wide uppercase">
              Tamanho da Fonte
            </label>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-charcoal-600">12px</span>
                <span className="text-lg font-semibold text-burgundy-600">{settings.fontSize}px</span>
                <span className="text-sm text-charcoal-600">24px</span>
              </div>
              <input
                type="range"
                min="12"
                max="24"
                value={settings.fontSize}
                onChange={(e) => onSettingsChange({ ...settings, fontSize: parseInt(e.target.value) })}
                className="w-full h-2 bg-ivory-300 rounded-full appearance-none cursor-pointer accent-burgundy-600"
                style={{
                  background: `linear-gradient(to right, #de4f4f 0%, #de4f4f ${((settings.fontSize - 12) / 12) * 100}%, #e6ceb2 ${((settings.fontSize - 12) / 12) * 100}%, #e6ceb2 100%)`
                }}
              />
            </div>
          </div>
          
          {/* Line Height */}
          <div>
            <label className="block text-sm font-semibold text-charcoal-700 mb-4 tracking-wide uppercase">
              Espaçamento entre Linhas
            </label>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-charcoal-600">1.2</span>
                <span className="text-lg font-semibold text-burgundy-600">{settings.lineHeight}</span>
                <span className="text-sm text-charcoal-600">2.0</span>
              </div>
              <input
                type="range"
                min="1.2"
                max="2.0"
                step="0.1"
                value={settings.lineHeight}
                onChange={(e) => onSettingsChange({ ...settings, lineHeight: parseFloat(e.target.value) })}
                className="w-full h-2 bg-ivory-300 rounded-full appearance-none cursor-pointer accent-burgundy-600"
                style={{
                  background: `linear-gradient(to right, #de4f4f 0%, #de4f4f ${((settings.lineHeight - 1.2) / 0.8) * 100}%, #e6ceb2 ${((settings.lineHeight - 1.2) / 0.8) * 100}%, #e6ceb2 100%)`
                }}
              />
            </div>
          </div>
          
          {/* Container Width */}
          <div>
            <label className="block text-sm font-semibold text-charcoal-700 mb-4 tracking-wide uppercase">
              Largura do Texto
            </label>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-charcoal-600">400px</span>
                <span className="text-lg font-semibold text-burgundy-600">{settings.containerWidth}px</span>
                <span className="text-sm text-charcoal-600">900px</span>
              </div>
              <input
                type="range"
                min="400"
                max="900"
                step="50"
                value={settings.containerWidth}
                onChange={(e) => onSettingsChange({ ...settings, containerWidth: parseInt(e.target.value) })}
                className="w-full h-2 bg-ivory-300 rounded-full appearance-none cursor-pointer accent-burgundy-600"
                style={{
                  background: `linear-gradient(to right, #de4f4f 0%, #de4f4f ${((settings.containerWidth - 400) / 500) * 100}%, #e6ceb2 ${((settings.containerWidth - 400) / 500) * 100}%, #e6ceb2 100%)`
                }}
              />
            </div>
          </div>
        </div>
        
        {/* Footer */}
        <div className="p-8 bg-gradient-to-r from-ivory-50 to-ivory-100 border-t border-ivory-300">
          <button
            onClick={onClose}
            className="w-full py-4 bg-gradient-to-r from-burgundy-600 to-burgundy-700 text-ivory-50 rounded-2xl hover:shadow-glow hover:scale-[1.02] transition-all duration-300 font-sans font-semibold text-lg tracking-wide"
          >
            Concluir
          </button>
        </div>
      </div>
    </div>
  );
}
