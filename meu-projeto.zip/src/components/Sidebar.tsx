import type { Chapter } from '../types';

interface SidebarProps {
  chapters: Chapter[];
  currentChapter: string;
  onChapterSelect: (href: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ chapters, currentChapter, onChapterSelect, isOpen, onClose }: SidebarProps) {
  return (
    <>
      {/* Overlay with blur */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-charcoal-900/60 backdrop-blur-sm z-40 md:hidden transition-opacity duration-300"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 left-0 h-full w-80 bg-gradient-to-b from-ivory-50 to-ivory-100 z-50
          transform transition-transform duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]
          shadow-elegant
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
          md:translate-x-0 md:static md:z-0 md:shadow-none
        `}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-6 border-b border-ivory-300 bg-gradient-to-r from-burgundy-600 to-burgundy-700">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-display font-semibold text-ivory-50 tracking-wide">
                  Carte du Jour
                </h2>
                <p className="text-ivory-200 text-sm mt-1 font-sans font-light">
                  Menu de Capítulos
                </p>
              </div>
              <button
                onClick={onClose}
                className="md:hidden p-2 rounded-lg hover:bg-burgundy-500 text-ivory-50 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
          
          {/* Chapter List */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className="space-y-2">
              {chapters.map((chapter) => (
                <button
                  key={chapter.id}
                  onClick={() => {
                    onChapterSelect(chapter.href);
                    onClose();
                  }}
                  className={`
                    w-full text-left px-5 py-4 rounded-xl transition-all duration-300
                    group relative overflow-hidden
                    ${currentChapter === chapter.href
                      ? 'bg-gradient-to-r from-burgundy-600 to-burgundy-700 text-ivory-50 shadow-lg shadow-burgundy-600/30'
                      : 'text-charcoal-700 hover:bg-ivory-200 hover:shadow-soft'
                    }
                  `}
                >
                  <div className="flex items-center gap-4 relative z-10">
                    <span className={`
                      text-lg transition-transform duration-300
                      ${currentChapter === chapter.href ? 'scale-110' : 'group-hover:scale-110'}
                    `}>
                      {chapter.label.includes('Preface') || chapter.label.includes('Afterword') ? '�' : '�📖'}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-serif text-base leading-snug truncate">
                        {chapter.label}
                      </p>
                    </div>
                    {currentChapter === chapter.href && (
                      <span className="text-ivory-300 animate-pulse">
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
          
          {/* Footer */}
          <div className="p-6 border-t border-ivory-300 bg-ivory-50">
            <div className="text-center">
              <p className="text-xs text-charcoal-500 font-sans tracking-widest uppercase mb-2">
                Mise en Place
              </p>
              <div className="flex items-center justify-center gap-2 text-burgundy-600">
                <span className="text-xl">🍷</span>
                <span className="text-xl">✨</span>
                <span className="text-xl">📖</span>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
