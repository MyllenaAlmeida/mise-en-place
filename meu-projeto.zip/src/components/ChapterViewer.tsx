import { useEffect, useRef, useState } from 'react';
import type { ReaderSettings } from '../types';

interface ChapterViewerProps {
  chapterUrl: string;
  settings: ReaderSettings;
  onNext: () => void;
  onPrev: () => void;
  hasNext: boolean;
  hasPrev: boolean;
}

export default function ChapterViewer({ 
  chapterUrl, 
  settings, 
  onNext, 
  onPrev, 
  hasNext, 
  hasPrev 
}: ChapterViewerProps) {
  const [content, setContent] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    async function loadChapter() {
      setIsLoading(true);
      try {
        const response = await fetch(chapterUrl);
        const html = await response.text();
        setContent(html);
      } catch (error) {
        console.error('Error loading chapter:', error);
      } finally {
        setIsLoading(false);
      }
    }

    loadChapter();
  }, [chapterUrl]);

  useEffect(() => {
    if (iframeRef.current && content) {
      const iframe = iframeRef.current;
      const doc = iframe.contentDocument || iframe.contentWindow?.document;
      
      if (doc) {
        doc.open();
        doc.write(content);
        doc.close();

        // Apply custom styles
        const style = doc.createElement('style');
        style.textContent = `
          @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500&family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap');
          
          * {
            box-sizing: border-box;
          }
          
          body {
            font-family: 'Cormorant Garamond', Georgia, serif !important;
            font-size: ${settings.fontSize}px !important;
            line-height: ${settings.lineHeight} !important;
            max-width: ${settings.containerWidth}px !important;
            margin: 0 auto !important;
            padding: 60px 40px !important;
            color: #2c2c2c !important;
            background: transparent !important;
          }
          
          h1, h2, h3 {
            font-family: 'Playfair Display', Georgia, serif !important;
            color: #8c2727 !important;
            font-weight: 600 !important;
          }
          
          p {
            margin-bottom: 1.5em !important;
            text-align: justify !important;
            text-indent: 2em !important;
            line-height: ${settings.lineHeight} !important;
          }
          
          p:first-of-type {
            text-indent: 0 !important;
          }
          
          .chapter-title {
            text-align: center !important;
            font-size: 2.5em !important;
            margin-bottom: 2.5em !important;
            padding-bottom: 1.5em !important;
            border-bottom: 3px solid #de4f4f !important;
            font-family: 'Playfair Display', Georgia, serif !important;
            color: #8c2727 !important;
            font-weight: 600 !important;
          }
          
          .calibre7, .userstuff1, .userstuff2, .calibre1 {
            font-family: 'Cormorant Garamond', Georgia, serif !important;
          }
          
          .heading {
            font-family: 'Playfair Display', Georgia, serif !important;
            color: #8c2727 !important;
            font-size: 2em !important;
            text-align: center !important;
            margin: 2em 0 !important;
          }
        `;
        doc.head.appendChild(style);
      }
    }
  }, [content, settings]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowRight' || e.key === ' ') {
      e.preventDefault();
      if (hasNext) onNext();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      if (hasPrev) onPrev();
    }
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-ivory-50 via-ivory-100 to-ivory-50" onKeyDown={handleKeyDown} tabIndex={0}>
      {/* Chapter Content */}
      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full animate-fade-in">
            <div className="text-4xl mb-4 animate-bounce">📖</div>
            <div className="text-burgundy-600 text-lg font-serif italic">Carregando capítulo...</div>
          </div>
        ) : (
          <iframe
            ref={iframeRef}
            title="Chapter Content"
            className="w-full h-full border-0"
            sandbox="allow-same-origin"
          />
        )}
      </div>
      
      {/* Navigation Controls */}
      <div className="flex items-center justify-between px-8 py-5 bg-gradient-to-r from-ivory-50 to-ivory-100 border-t border-ivory-300 shadow-soft">
        <button
          onClick={onPrev}
          disabled={!hasPrev}
          className={`
            group flex items-center gap-2 px-6 py-3 rounded-xl
            transition-all duration-300 font-sans font-medium
            ${hasPrev 
              ? 'bg-gradient-to-r from-burgundy-600 to-burgundy-700 text-ivory-50 hover:shadow-glow hover:scale-105' 
              : 'bg-ivory-200 text-charcoal-400 cursor-not-allowed'
            }
          `}
          aria-label="Capítulo anterior"
        >
          <svg className="w-5 h-5 transition-transform group-hover:-translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          <span>Anterior</span>
        </button>
        
        <div className="flex items-center gap-3 text-charcoal-600">
          <span className="text-sm font-sans">Use</span>
          <kbd className="px-2 py-1 bg-ivory-200 rounded text-xs font-mono border border-ivory-300">←</kbd>
          <kbd className="px-2 py-1 bg-ivory-200 rounded text-xs font-mono border border-ivory-300">→</kbd>
          <span className="text-sm font-sans">para navegar</span>
        </div>
        
        <button
          onClick={onNext}
          disabled={!hasNext}
          className={`
            group flex items-center gap-2 px-6 py-3 rounded-xl
            transition-all duration-300 font-sans font-medium
            ${hasNext 
              ? 'bg-gradient-to-r from-burgundy-600 to-burgundy-700 text-ivory-50 hover:shadow-glow hover:scale-105' 
              : 'bg-ivory-200 text-charcoal-400 cursor-not-allowed'
            }
          `}
          aria-label="Próximo capítulo"
        >
          <span>Próximo</span>
          <svg className="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </div>
  );
}
