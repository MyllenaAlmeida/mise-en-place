import { useEffect, useState } from 'react';
import {
  UtensilsCrossed,
  Gem,
  Clock,
  Tag,
  FileText,
  BookOpen,
  ArrowRight,
  Sparkles,
  Heart,
  Leaf,
  ChefHat,
  Sun,
  HeartPulse,
  MessageCircle,
} from 'lucide-react';
import type { Chapter } from '../types';
import type { BookMetadata } from '../hooks/useChapters';

interface HomePageProps {
  chapters: Chapter[];
  bookInfo: BookMetadata | null;
  onStartReading: (chapterIndex: number) => void;
}

const WORDS_PER_MINUTE = 200;

function extractPreview(html: string): { excerpt: string; readingTime: number } {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('style, script').forEach((el) => el.remove());
  const fullText = (doc.body.textContent || '').replace(/\s+/g, ' ').trim();

  const wordCount = fullText.length ? fullText.split(' ').length : 0;
  const readingTime = Math.max(1, Math.round(wordCount / WORDS_PER_MINUTE));

  // AO3 cover pages (preface) are mostly a tag/metadata table, not prose, and
  // every chapter repeats its own title in a couple of headings — drop all of
  // that before building the excerpt so it reads as an actual summary.
  doc.querySelectorAll('.tags, .message, .chapter-title, .heading').forEach((el) => el.remove());
  doc.querySelectorAll('p').forEach((p) => {
    if (p.textContent?.trim().toLowerCase() === 'chapter notes') p.remove();
  });
  const proseText = (doc.body.textContent || '').replace(/\s+/g, ' ').trim();

  const excerptLimit = 420;
  let excerpt = proseText.slice(0, excerptLimit);
  if (proseText.length > excerptLimit) {
    excerpt = excerpt.slice(0, excerpt.lastIndexOf(' ')) + '…';
  }

  return { excerpt, readingTime };
}

export default function HomePage({ chapters, bookInfo, onStartReading }: HomePageProps) {
  const [textSize, setTextSize] = useState(16);
  const [selectedChapterIndex, setSelectedChapterIndex] = useState(0);
  const [preview, setPreview] = useState<{ excerpt: string; readingTime: number } | null>(null);
  const [previewLoading, setPreviewLoading] = useState(true);

  const selectedChapter = chapters[selectedChapterIndex];

  useEffect(() => {
    if (!selectedChapter) return;

    let cancelled = false;
    setPreviewLoading(true);

    fetch(selectedChapter.href)
      .then((res) => res.text())
      .then((html) => {
        if (cancelled) return;
        setPreview(extractPreview(html));
      })
      .catch(() => {
        if (!cancelled) setPreview(null);
      })
      .finally(() => {
        if (!cancelled) setPreviewLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedChapter]);

  const tags = [
    { icon: Heart, label: 'ROMANCE SLOW BURN', color: 'bg-rose-50 text-rose-700 border-rose-200' },
    { icon: Leaf, label: 'CONFEITARIA VEGANA', color: 'bg-green-50 text-green-700 border-green-200' },
    { icon: ChefHat, label: 'CHEF X ESTAGIÁRIA', color: 'bg-amber-50 text-amber-700 border-amber-200' },
    { icon: Sun, label: 'RECIFE / CAFETERIA', color: 'bg-yellow-50 text-yellow-700 border-yellow-200' },
    { icon: HeartPulse, label: 'CURA DE TRAUMA', color: 'bg-blue-50 text-blue-700 border-blue-200' },
    { icon: MessageCircle, label: 'COMUNICAÇÃO SAUDÁVEL', color: 'bg-purple-50 text-purple-700 border-purple-200' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="px-8 py-5 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 flex items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-sm">
              <UtensilsCrossed className="w-5 h-5" strokeWidth={2.25} />
            </div>
            <div>
              <h1 className="font-display text-xl font-semibold text-gray-800 tracking-wide">
                Racine & Café
              </h1>
              <p className="text-[11px] font-mono text-gray-500 uppercase tracking-[0.15em]">
                Mise en Place Reader
              </p>
            </div>
          </div>

          {/* Right Side Controls */}
          <div className="flex items-center gap-3">
            {/* Bancada */}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 rounded-full border border-gray-300">
              <Gem className="w-3.5 h-3.5 text-gray-500" />
              <span className="text-xs font-mono font-medium text-gray-700">Bancada: Mármore</span>
            </div>

            {/* Text Size Controls */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => setTextSize(Math.max(12, textSize - 2))}
                className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded border border-gray-300 hover:bg-gray-200 transition-colors"
                aria-label="Diminuir fonte"
              >
                <span className="text-xs font-mono">A-</span>
              </button>
              <button
                onClick={() => setTextSize(16)}
                className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded border border-gray-300 hover:bg-gray-200 transition-colors"
                aria-label="Redefinir fonte"
              >
                <span className="text-sm font-mono">A</span>
              </button>
              <button
                onClick={() => setTextSize(Math.min(24, textSize + 2))}
                className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded border border-gray-300 hover:bg-gray-200 transition-colors"
                aria-label="Aumentar fonte"
              >
                <span className="text-base font-mono">A+</span>
              </button>
            </div>

            {/* Dropdown */}
            <select
              value={selectedChapterIndex}
              onChange={(e) => setSelectedChapterIndex(parseInt(e.target.value, 10))}
              className="px-3 py-1.5 bg-gray-100 rounded border border-gray-300 text-xs font-mono font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              {chapters.map((chapter, index) => (
                <option key={chapter.id} value={index}>
                  {chapter.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-8 py-10">
        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden border-t-4 border-orange-400">
          {/* Card Header */}
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-orange-500" />
                <span className="text-sm font-mono font-semibold tracking-wide text-gray-800">
                  FICHA TÉCNICA N° {String(selectedChapterIndex + 1).padStart(2, '0')}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-gray-600">
                <Clock className="w-3.5 h-3.5" />
                <span className="text-xs font-mono">
                  Tempo de Leitura: {previewLoading ? '...' : `~${preview?.readingTime ?? '-'} min`}
                </span>
              </div>
            </div>
          </div>

          {/* Card Content */}
          <div className="p-6" style={{ fontSize: `${textSize}px` }}>
            {/* Title */}
            <h2 className="font-display text-3xl font-bold text-gray-900 mb-3 text-center">
              {selectedChapter?.label ?? bookInfo?.title}
            </h2>

            {/* Author */}
            <div className="text-center mb-6">
              <p className="text-gray-600 text-sm italic font-serif">
                Autoria: {bookInfo?.author} — {bookInfo?.title}
              </p>
            </div>

            {/* Tags Section */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Tag className="w-4 h-4 text-gray-500" />
                <h3 className="text-sm font-mono font-semibold tracking-wide text-gray-800">
                  INSUMOS & NOTAÇÕES DE BANCADA (TAGS):
                </h3>
              </div>

              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => (
                  <button
                    key={tag.label}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border ${tag.color} hover:shadow-md transition-all duration-200`}
                  >
                    <tag.icon className="w-3.5 h-3.5" strokeWidth={2.25} />
                    <span className="text-xs font-mono font-medium">{tag.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Summary Section */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="w-4 h-4 text-gray-500" />
                <h3 className="text-sm font-mono font-semibold tracking-wide text-gray-800">
                  RESUMO DO CAPÍTULO:
                </h3>
              </div>

              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 min-h-[6rem]">
                {previewLoading ? (
                  <p className="text-gray-400 text-sm font-serif italic">Carregando prévia...</p>
                ) : (
                  <p className="text-gray-700 leading-relaxed text-sm font-serif">
                    {preview && preview.excerpt.length >= 40 ? preview.excerpt : bookInfo?.description}
                  </p>
                )}
              </div>
            </div>

            {/* Start Reading Button */}
            <div className="flex justify-center mt-8">
              <button
                onClick={() => onStartReading(selectedChapterIndex)}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-xl font-semibold text-sm hover:shadow-lg hover:scale-105 transition-all duration-300 flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                <span>Iniciar Leitura</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Floating Button */}
      <button className="fixed bottom-6 right-6 px-5 py-2.5 bg-white rounded-full shadow-lg border border-gray-300 text-gray-700 font-medium text-sm hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-orange-500" />
        <span>Peça ao Gemini</span>
      </button>
    </div>
  );
}
