import { useState, useEffect } from 'react';
import { useChapters } from './hooks/useChapters';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useTheme } from './hooks/useTheme';
import type { ReaderSettings } from './types';
import Sidebar from './components/Sidebar';
import ChapterViewer from './components/ChapterViewer';
import SettingsPanel from './components/SettingsPanel';
import Button from './components/Button';
import HomePage from './components/HomePage';

function App() {
  const [isReading, setIsReading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  
  const { changeTheme, getThemeClasses } = useTheme();
  const themeClasses = getThemeClasses();
  
  const [settings, setSettings] = useLocalStorage<ReaderSettings>('readerSettings', {
    fontSize: 18,
    lineHeight: 1.8,
    containerWidth: 750,
    theme: 'light',
  });

  const { chapters, bookInfo, isLoading: chaptersLoading } = useChapters();

  // Sync theme with settings
  useEffect(() => {
    changeTheme(settings.theme);
  }, [settings.theme, changeTheme]);

  // Load saved progress
  useEffect(() => {
    const saved = localStorage.getItem('miseEnPlaceProgress');
    if (saved) {
      setCurrentChapterIndex(parseInt(saved, 10));
    }
  }, []);

  // Save reading progress
  useEffect(() => {
    localStorage.setItem('miseEnPlaceProgress', currentChapterIndex.toString());
  }, [currentChapterIndex]);

  const handleNextChapter = () => {
    if (currentChapterIndex < chapters.length - 1) {
      setCurrentChapterIndex(prev => prev + 1);
    }
  };

  const handlePrevChapter = () => {
    if (currentChapterIndex > 0) {
      setCurrentChapterIndex(prev => prev - 1);
    }
  };

  const handleChapterSelect = (href: string) => {
    const index = chapters.findIndex(ch => ch.href === href);
    if (index !== -1) {
      setCurrentChapterIndex(index);
    }
  };

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSettingsOpen(false);
        setSidebarOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Show loading screen or home page
  if (chaptersLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-ivory-50 via-ivory-100 to-ivory-50 flex items-center justify-center">
        <div className="text-center animate-fade-in">
          <div className="text-6xl mb-6 animate-bounce">📖</div>
          <div className="text-burgundy-600 text-2xl font-display font-semibold mb-2">
            Mise en Place
          </div>
          <div className="text-charcoal-500 font-serif italic text-lg">
            Carregando...
          </div>
        </div>
      </div>
    );
  }

  // Show home page if not reading
  if (!isReading) {
    return (
      <HomePage
        chapters={chapters}
        bookInfo={bookInfo}
        onStartReading={(chapterIndex) => {
          setCurrentChapterIndex(chapterIndex);
          setIsReading(true);
        }}
      />
    );
  }

  const currentChapter = chapters[currentChapterIndex];

  return (
    <div className={`min-h-screen ${themeClasses.bg} ${themeClasses.text}`}>
      {/* Top Bar */}
      <header className={`h-20 border-b ${themeClasses.border} ${themeClasses.container} flex items-center justify-between px-6 sticky top-0 z-30 shadow-soft backdrop-blur-md bg-opacity-90`}>
        <div className="flex items-center gap-4">
          <Button
            variant="icon"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            aria-label="Menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </Button>
          <div className="flex items-center gap-3">
            <div className="text-2xl">🍷</div>
            <div>
              <h1 className="font-display font-semibold text-xl tracking-wide text-burgundy-600">
                {bookInfo?.title || 'Mise en Place'}
              </h1>
              <p className="text-sm opacity-70 font-serif italic">
                {bookInfo?.author || 'littleslightlymad'}
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Button
            variant="secondary"
            onClick={() => setIsReading(false)}
          >
            ← Voltar ao Menu
          </Button>
          <Button
            variant="icon"
            onClick={() => setSettingsOpen(true)}
            aria-label="Configurações"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </Button>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="h-1.5 bg-ivory-200 shadow-inner">
        <div
          className="h-full bg-gradient-to-r from-burgundy-600 to-burgundy-700 transition-all duration-500 ease-out shadow-glow"
          style={{ width: `${((currentChapterIndex + 1) / chapters.length) * 100}%` }}
        />
      </div>

      {/* Main Content */}
      <div className="flex h-[calc(100vh-85px)]">
        <Sidebar
          chapters={chapters}
          currentChapter={currentChapter?.href || ''}
          onChapterSelect={handleChapterSelect}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
        
        <main className="flex-1 flex flex-col">
          {currentChapter && (
            <ChapterViewer
              chapterUrl={currentChapter.href}
              settings={settings}
              onNext={handleNextChapter}
              onPrev={handlePrevChapter}
              hasNext={currentChapterIndex < chapters.length - 1}
              hasPrev={currentChapterIndex > 0}
            />
          )}
        </main>
      </div>

      {/* Settings Panel */}
      {settingsOpen && (
        <SettingsPanel
          settings={settings}
          onSettingsChange={setSettings}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </div>
  );
}

export default App;
